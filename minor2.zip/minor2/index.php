<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>

<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['regno']);
      $mypassword = mysqli_real_escape_string($db,$_POST['pass']); 
      
      $sql = "SELECT * FROM stu_data WHERE regno = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
	  
		
      if($count == 1) {
        // session_register("myusername");
		 $_SESSION['loggedin'] = TRUE;
         $_SESSION['login_user'] = $myusername;
		 ?>
		<script>
		
		swal.fire({
				icon: 'success',
                title: 'Success',
                text: 'Login Successful'
}).then(function() {
    window.location = "home.php";
});

		 </script>
		 <?php
	  }
	  else
	  {
		  ?>
         <script>
		
		swal.fire({
				icon: 'error',
                title: 'Login Failure',
                text: 'Check login credentials'
}).then(function() {
    window.location = "index.php";
});
        </script>
		<?php
      }
   }


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - FeeConnect</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <section id="login">
        <h2>Login to FeeConnect</h2>
        <form id="loginform" action="index.php" method="post">
            <input type="text"  name="regno" id="regno" placeholder="Register Number" required>
            <input type="password"  name="pass" id="pass" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </section>
    <script src="scripts.js"></script>
</body>
</html>
